<template>
  <div class="d-flex justify-content-center align-items-center">
    <div class="p-4 position-relative">
      <button type="button" class="btn-close position-absolute top-0 end-0 m-3" aria-label="Close" @click="goBack"></button>
      <!-- Cart Summary -->
      <div class="mt-5">
        <h2>Request List</h2>
        <ul class="list-group">
          <li v-for="(item, index) in request_list" :key="index" class="list-group-item d-flex justify-content-between align-items-center text-wrap">
            <div class="wrap-text">
              <p>{{ item.request_for }}</p>
              <p>{{ item.data }}</p>
              <p>{{ item.statuscheck }}</p>
            </div>
            <div v-if="$store.getters.authenticateUser.role === 'admin'" class="btn-group" role="group" aria-label="Actions">
              <button v-show="item.statuscheck === 'pending'" type="button" class="btn btn-success" @click="approve(item.id)">Approve</button>
              <button v-show="item.statuscheck === 'pending'" type="button" class="btn btn-dark" @click="decline(item.id)">Decline</button>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      email: "",
      password: "",
      rememberMe: false,
      request_list: []
    };
  },
  methods: {
    async withdraw(id) {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/delete/managers/'+id,{
          method: 'DELETE',
          headers: {
            'Authentication-Token': this.$store.getters.authenticateUser.auth_token,
            'Content-Type': 'application/json',
          }
        });
        if (response.status === 200) {
          const data = await response.json();
          alert(data.message)
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    },    
    login() {
      // Implement your login logic here
      // Access email, password, and rememberMe using this.email, this.password, this.rememberMe
      // You can make an API call or perform any authentication logic
      // After successful login, you can emit an event or navigate to another page
      console.log("Login Clicked");

      // Reset the form fields
      this.email = "";
      this.password = "";
      this.rememberMe = false;
    },
    async approve(id) {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/apprequest/response/'+id, {
          method: 'POST',
          headers: {
            'Authentication-Token': this.$store.getters.authenticateUser.auth_token,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            "response":"approve"
          })
        });
        if (response.status === 200) {
          const data = await response.json();
          alert(data.message)
          this.loadRequests()
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    },
    async decline(id) {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/apprequest/response/'+id, {
          method: 'POST',
          headers: {
            'Authentication-Token': this.$store.getters.authenticateUser.auth_token,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            "response":"decline"
          })
        });
        if (response.status === 200) {
          const data = await response.json();
          alert(data.message)
          this.loadRequests()
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    },      
    againAddClick(id){
        this.$store.commit('addAgain',id)
    },
    removeClick(id){
        this.$store.commit('removeFromCart',id)
    },    
    goToPay(){
        this.$router.push('/user/pay')
    },
    goBack(){
      this.$router.go(-1)
    },
    goHome(){
      this.$router.push('/new/view')
    },
    async loadRequests() {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/apprequest/get', {
          method: 'GET',
          headers: {
            'Authentication-Token': this.$store.getters.authenticateUser.auth_token,
            'Content-Type': 'application/json',
          },
        });
        if (response.status === 200) {
          const data = await response.json();
          console.log(data, "categories fetched")
          this.request_list=data;
          console.log(this.request_list,"loaded data")
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    },
    async loadManagers() {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/get/managers', {
          method: 'GET',
          headers: {
            'Authentication-Token': this.$store.getters.authenticateUser.auth_token,
            'Content-Type': 'application/json',
          },
        });
        if (response.status === 200) {
          const data = await response.json();
          console.log(data, "categories fetched")
          this.managers_list=data;
          console.log(this.managers_list,"loaded data")
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    }            
  },
  mounted() {
    const source = new EventSource("http://localhost:8000/api/stream");
    source.addEventListener(sessionStorage.getItem('email'), event => {
      let data = JSON.parse(event.data);
      this.sseMessage = data.message;
    }, false);
    this.loadRequests();
  },  
};
</script>

<style scoped>
/* Add your custom styles here */
.card {
  max-width: 400px;
  width: 100%;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}
</style>
